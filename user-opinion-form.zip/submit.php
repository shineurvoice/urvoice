<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = htmlspecialchars($_POST['name']);
    $dob = htmlspecialchars($_POST['dob']);
    $mobile = htmlspecialchars($_POST['mobile']);
    $category = htmlspecialchars($_POST['category']);
    $opinion = htmlspecialchars($_POST['opinion']);

    echo "<!DOCTYPE html><html><head><title>Submission Result</title></head><body>";
    echo "<h2>Thank you for your submission!</h2>";
    echo "<p><strong>Name:</strong> $name</p>";
    echo "<p><strong>Date of Birth:</strong> $dob</p>";
    echo "<p><strong>Mobile No.:</strong> $mobile</p>";
    echo "<p><strong>Category:</strong> $category</p>";
    echo "<p><strong>Opinion:</strong> $opinion</p>";

    if (isset($_FILES['fileUpload']) && $_FILES['fileUpload']['error'] === 0) {
        $file = $_FILES['fileUpload'];
        $fileName = basename($file['name']);
        $fileTmp = $file['tmp_name'];
        $fileExt = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
        $allowed = ['jpg', 'jpeg', 'png', 'pdf', 'docx'];

        if (in_array($fileExt, $allowed)) {
            if ($file['size'] <= 2 * 1024 * 1024) {
                $newFileName = uniqid() . "." . $fileExt;
                $uploadDir = "uploads/";

                if (!is_dir($uploadDir)) {
                    mkdir($uploadDir, 0755, true);
                }

                $uploadPath = $uploadDir . $newFileName;

                if (move_uploaded_file($fileTmp, $uploadPath)) {
                    echo "<p>File uploaded: <a href='$uploadPath' target='_blank'>$fileName</a></p>";
                } else {
                    echo "<p style='color:red;'>Failed to upload file.</p>";
                }
            } else {
                echo "<p style='color:red;'>File too large (max 2MB).</p>";
            }
        } else {
            echo "<p style='color:red;'>File type not allowed.</p>";
        }
    }

    echo "</body></html>";
}
?>