# User Opinion Submission Form

A simple web form for submitting user opinions along with file uploads.

## Features
- Collects name, date of birth, mobile number
- Users can share their opinions under selected categories
- Optional file upload with type and size validation

## How to Use
1. Clone this repo and upload to a PHP-enabled server.
2. Open `index.html` in the browser.
3. Uploaded files are stored in the `uploads/` directory.

## Allowed File Types
- jpg, jpeg, png, pdf, docx

## License
MIT
